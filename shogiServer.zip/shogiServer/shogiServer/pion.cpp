#include "pion.h"

Shogi::pion::pion()
{

}
