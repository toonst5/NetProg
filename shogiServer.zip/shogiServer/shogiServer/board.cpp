#include "board.h"

Shogi::board::board()
{

}
