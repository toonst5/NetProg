#include "applause.h"
#include <QBrush>
#include <QGraphicsTextItem>

Shogi::Applause::Applause()
{

}

Shogi::Applause::Applause(QString name, QGraphicsItem *parent): QGraphicsRectItem(parent)
{
    setRect(560,-250,50,50);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);

    text = new QGraphicsTextItem(name,this);
    text->setPos(560,-250);

    setAcceptHoverEvents(true);
}

void Shogi::Applause::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    emit clicked();
}

void Shogi::Applause::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::cyan);
    setBrush(brush);
}

void Shogi::Applause::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);
}
