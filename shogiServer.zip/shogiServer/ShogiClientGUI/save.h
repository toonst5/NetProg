#ifndef SAVE_H
#define SAVE_H

#include <QGraphicsRectItem>
#include <QGraphicsSceneMouseEvent>

namespace Shogi
{
class Save:public QObject, public QGraphicsRectItem
{
    Q_OBJECT
private:
    QGraphicsTextItem* text;

public:
    Save();
    Save(QString name, QGraphicsItem* parent=NULL);

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

signals:
    void clicked();
};
}

#endif // SAVE_H
