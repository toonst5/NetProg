#ifndef APPLAUSE_H
#define APPLAUSE_H

#include <QGraphicsRectItem>
#include <QGraphicsSceneMouseEvent>

namespace Shogi
{
class Applause:public QObject, public QGraphicsRectItem
{
    Q_OBJECT
private:
    QGraphicsTextItem* text;

public:
    Applause();
    Applause(QString name, QGraphicsItem* parent=NULL);

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

signals:
    void clicked();
};
}

#endif // APPLAUSE_H
