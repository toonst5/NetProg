#include "Save.h"
#include <QBrush>
#include <QGraphicsTextItem>

Shogi::Save::Save()
{

}

Shogi::Save::Save(QString name, QGraphicsItem *parent): QGraphicsRectItem(parent)
{
    setRect(425,-250,50,50);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);

    text = new QGraphicsTextItem(name,this);
    text->setPos(460,-250);

    setAcceptHoverEvents(true);
}

void Shogi::Save::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    emit clicked();
}

void Shogi::Save::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::cyan);
    setBrush(brush);
}

void Shogi::Save::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);
}
