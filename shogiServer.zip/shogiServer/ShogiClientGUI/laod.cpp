#include "laod.h"
#include <QBrush>
#include <QGraphicsTextItem>

Shogi::Laod::Laod()
{

}

Shogi::Laod::Laod(QString name, QGraphicsItem *parent): QGraphicsRectItem(parent)
{
    setRect(560,-250,50,50);
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);

    text = new QGraphicsTextItem(name,this);
    text->setPos(560,-250);

    setAcceptHoverEvents(true);
}

void Shogi::Laod::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    emit clicked();
}

void Shogi::Laod::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::cyan);
    setBrush(brush);
}

void Shogi::Laod::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    QBrush brush;
    brush.setStyle(Qt::SolidPattern);
    brush.setColor(Qt::darkCyan);
    setBrush(brush);
}
