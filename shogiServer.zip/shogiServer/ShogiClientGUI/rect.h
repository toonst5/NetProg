#ifndef RECT_H
#define RECT_H

#include <QGraphicsRectItem>

namespace Shogi
{
class rect: public QGraphicsPolygonItem
{
private:

public:
    rect();
};
}
#endif // RECT_H
