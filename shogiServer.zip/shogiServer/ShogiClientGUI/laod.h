#ifndef LAOD_H
#define LAOD_H


#include <QGraphicsRectItem>
#include <QGraphicsSceneMouseEvent>

namespace Shogi
{
class Laod:public QObject, public QGraphicsRectItem
{
    Q_OBJECT
private:
    QGraphicsTextItem* text;

public:
    Laod();
    Laod(QString name, QGraphicsItem* parent=NULL);

    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void hoverEnterEvent(QGraphicsSceneHoverEvent *event);
    void hoverLeaveEvent(QGraphicsSceneHoverEvent *event);

signals:
    void clicked();
};
}

#endif // LAOD_H

